package proxy.framework;

public interface Developer {
	
	void develop();
	
}
