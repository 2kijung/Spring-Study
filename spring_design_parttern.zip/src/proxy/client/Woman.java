package proxy.client;

import proxy.framework.Developer;

public class Woman implements Developer{
	public void develop() {
		System.out.println("Ruby로 개발한다.");
	}
}
